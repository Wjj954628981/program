DELETE
FROM member4;

DELETE 
FROM title4;

DELETE 
FROM book4;
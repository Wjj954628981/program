insert into team values('A','Red',10,'2');
insert into team values('B','Green',12,'3');
insert into team values('C','Blue',8,'4');

insert into player values('a',18,'A');
insert into player values('b',18,'A');
insert into player values('c',18,'A');
insert into player values('d',18,'A');
insert into player values('e',18,'A');
insert into player values('f',18,'A');
insert into player values('g',18,'A');
insert into player values('h',18,'A');
insert into player values('i',18,'A');
insert into player values('j',18,'A');

insert into player values('a1',18,'B');
insert into player values('b1',18,'B');
insert into player values('c1',18,'B');
insert into player values('d1',18,'B');
insert into player values('e1',18,'B');
insert into player values('f1',18,'B');
insert into player values('g1',18,'B');
insert into player values('h1',18,'B');
insert into player values('i1',18,'B');
insert into player values('k1',18,'B');
insert into player values('l1',18,'B');
insert into player values('m1',18,'B');

insert into player values('a2',18,'C');
insert into player values('b2',18,'C');
insert into player values('c2',18,'C');
insert into player values('d2',18,'C');
insert into player values('e2',18,'C');
insert into player values('f2',18,'C');
insert into player values('g2',18,'C');
insert into player values('h2',18,'C');

insert into coach values('x',40,'A');
insert into coach values('y',40,'A');
insert into coach values('z',40,'A');

insert into coach values('x1',40,'B');
insert into coach values('y1',40,'B');

insert into coach values('x2',40,'C');
insert into coach values('y2',40,'C');
insert into coach values('z2',40,'C');
insert into coach values('r2',40,'C');

insert into stadium values('D',100,'tianjin');
insert into stadium values('E',200,'beijing');
insert into stadium values('F',300,'shanghai');
insert into stadium values('G',400,'guangzhou');

insert into game values('A','B',001,3,'2016-03-12','3-1',50);
insert into game values('B','C',002,4,'2016-03-24','3-0',60);
insert into game values('C','A',003,5,'2016-04-02','2-1',70);

insert into practice values('A','D','2016-01-12');
insert into practice values('B','E','2016-01-16');
insert into practice values('C','F','2016-01-02');
insert into practice values('B','G','2016-01-25');
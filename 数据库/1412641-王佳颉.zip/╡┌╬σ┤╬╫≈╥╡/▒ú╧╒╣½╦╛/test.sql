exec p2 Tom;
exec p3 Tom,Buick
update inventory
set level=8000 where item='100';
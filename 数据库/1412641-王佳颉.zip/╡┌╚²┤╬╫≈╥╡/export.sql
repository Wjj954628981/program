select employeeID,firstname,lastname
from employees;